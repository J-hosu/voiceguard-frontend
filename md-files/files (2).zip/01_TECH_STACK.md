# 01. 기술 스택 (재추천)

> 프론트엔드 스펙 docx는 미확정이라 했으므로, 디자인과 **실제 백엔드 제약**을 다시 검토해 재추천합니다.
> 결론부터: **프레임워크는 Flutter 유지**가 타당합니다. 다만 원본 문서가 놓친 핵심 아키텍처 수정 —
> **온디바이스 STT** — 이 있습니다. 프레임워크가 아니라 이 부분이 진짜 조정 포인트입니다.

---

## 1. 프레임워크: Flutter (Dart) — 유지 권장

### 왜 다시 봐도 Flutter인가

판단 기준: **안드로이드 단일 타겟 · 프론트 입문자 · 5일 · AI 코드생성 활용 · 온디바이스 STT/마이크/알림/진동 필요.**

| 후보 | 이 프로젝트 적합성 | 판정 |
| --- | --- | --- |
| **Flutter** | 위젯 조립식이라 입문자가 결과를 보며 배우기 쉬움. Material 3 기본 내장(디자인 시스템 바로 호환). STT·녹음·WS·알림·진동 패키지 성숙. AI 코드생성 예제 풍부. | **채택** |
| React Native | 웹 지식 재활용은 되나 네이티브 오디오/STT 모듈 연동 이슈가 잦고 초기 설정이 까다로움 | 미채택 |
| Kotlin + Compose | 네이티브 STT 제어는 최고지만 5일 내 입문자 습득 난이도 과다 | 미채택 |
| WebView 하이브리드 | 마이크/STT/백그라운드 권한 처리가 번거롭고 네이티브 감이 떨어짐 | Flutter 실패 시 최후 대안 |

> **재추천의 핵심은 프레임워크 교체가 아니라 아키텍처 교정입니다.** 원본 스펙은 "3~5초 오디오 청크를 서버에 업로드하면 서버가 STT+분석"을 전제했지만, 실제 백엔드는 **텍스트만** 받습니다. 따라서 STT를 앱에서 처리해야 하고, 이는 어떤 프레임워크를 쓰든 동일하게 필요한 변경입니다. Flutter로도 `speech_to_text` 패키지로 충분히 커버됩니다.

### 언어/SDK

- Dart (null-safety), Flutter 최신 stable
- `minSdkVersion 26` (Android 8.0) / `targetSdkVersion 34` (Android 14)
- Material 3 (`useMaterial3: true`)

---

## 2. 패키지 목록 (pubspec 후보)

| 용도 | 패키지 | 비고 |
| --- | --- | --- |
| **온디바이스 STT** | `speech_to_text` | 안드로이드 SpeechRecognizer 래핑. **백엔드가 텍스트를 받으므로 필수.** 연속 인식은 세션 재시작 처리 필요(아래 주의) |
| 오디오 녹음(파일/원본 필요 시) | `record` | 파일 분석 화면·필요 시 raw 캡처 |
| 파일 선택 | `file_picker` | 음성 파일 업로드 화면 |
| WebSocket | `web_socket_channel` | 실시간 분석 `ws://.../ws/calls/analyze` |
| HTTP | `dio` | `GET /calls`, `/health`. 인터셉터·에러 처리 편함 (단순히 가고 싶으면 `http`) |
| 상태관리 | `flutter_riverpod` | **[확정]** WS/STT 스트림 구독 구조에 적합, 예제 풍부 |
| 라우팅 | `go_router` | 하단 탭 + 화면 스택 |
| 권한 | `permission_handler` | RECORD_AUDIO / POST_NOTIFICATIONS / READ_MEDIA_AUDIO |
| 로컬 알림 | `flutter_local_notifications` | 경고 알림 |
| 진동/햅틱 | `vibration` 또는 `HapticFeedback`(내장) | 위험 경고 시 |
| 로컬 저장 | `shared_preferences` | 설정(임계값·테마·큰글씨) |
| 위험도 원형 게이지 | `percent_indicator` | 84% 원형 게이지(화면 7) |
| 타임라인/막대 그래프 | `fl_chart` | 위험도 타임라인(화면 6) |
| 폰트 | `google_fonts`(Noto Sans KR) 또는 Pretendard 에셋 | 가독성·무료 라이선스 |
| 결과 공유 | `share_plus` | 결과 공유 버튼 |

### `speech_to_text` 주의점 (중요)

- 안드로이드 SpeechRecognizer는 **짧은 발화 위주**로 설계되어, 침묵이 몇 초 지속되면 자동 종료됩니다. **실시간 통화 감지처럼 계속 들어야 하는 경우**, `onStatus`/`onError`에서 종료를 감지해 **자동 재시작(listen 재호출)** 루프를 구현해야 합니다.
- 각 "최종 인식 결과(final result)"를 하나의 **발화 턴**으로 보고, `turn_index`를 1씩 증가시켜 WS `message`로 전송합니다.
- 화자 구분(diarization)은 온디바이스로 사실상 불가 → 캡처된 발화를 단일 role(예: `speaker_a`)로 전송하는 것을 기본으로 하고, role 규칙은 백엔드와 확인(`05_BACKEND_REQUESTS.md` 참고).

---

## 3. 폴더 구조 (feature-first 권장)

```text
lib/
  main.dart
  app.dart                      # MaterialApp, 테마, 라우터 주입
  core/
    theme/
      app_colors.dart           # 04_DESIGN_SYSTEM 색상 토큰
      app_typography.dart
      app_theme.dart            # Material3 ThemeData (라이트/다크)
    router/app_router.dart      # go_router
    config/env.dart             # baseUrlHttp, baseUrlWs (ngrok URL)
    utils/risk_level.dart       # risk_score → UI 등급 매핑 (단일 소스)
  data/
    models/
      call.dart                 # GET /calls 항목
      analysis_event.dart       # WS 응답(analysis_ack/phishing_detected/error)
      analysis_result.dart      # 통화 종료 후 요약(앱 내 집계)
    services/
      api_client.dart           # dio: /health, /calls
      ws_service.dart           # web_socket_channel 래퍼(start/message/이벤트 스트림)
      stt_service.dart          # speech_to_text 래퍼(재시작 루프 포함)
      storage_service.dart      # shared_preferences
    repositories/
      call_repository.dart      # 화면이 쓰는 진입점(REST+WS+STT 조합)
  features/
    onboarding/                 # 화면 1
    home/                       # 화면 2
    upload/                     # 화면 3
    realtime/                   # 화면 4·5 (감지+대화내용)
    alert/                      # 화면 6 (경고 모달)
    result/                     # 화면 7·8 (요약+근거상세)
    history/                    # 히스토리 목록
    settings/                   # 설정
    info/                       # 예방정보 / 대응방법(정적)
      # 각 feature = presentation(screens, widgets) + providers(riverpod)
  shared/
    widgets/
      risk_gauge.dart           # 원형 위험도 게이지
      risk_badge.dart           # 정상/주의/위험 배지(색+아이콘+텍스트)
      keyword_chip.dart         # 탐지 키워드 칩
      call_card.dart            # 히스토리/최근내역 카드(좌측 색 스트라이프)
```

---

## 4. 환경 설정 메모

- **Cleartext(HTTP) 차단**: Android 9+ 는 평문 HTTP를 기본 차단. 데모는 ngrok/cloudflared **HTTPS/WSS** 사용이 기본. 로컬 IP 직접 테스트 시 `network_security_config.xml`에 개발 서버 IP 예외 등록.
- `baseUrl`은 데모마다 바뀌는 ngrok URL이므로 `core/config/env.dart` 한 곳에서 관리.
- 필수 권한(AndroidManifest): `RECORD_AUDIO`, `INTERNET`, `POST_NOTIFICATIONS`(13+), `READ_MEDIA_AUDIO`(13+). 실행 중 런타임 요청은 온보딩 화면에서.
- 실기기(S24 Ultra) USB 디버깅 테스트 권장(마이크·STT는 에뮬레이터에서 불안정).

---

## 5. 상태관리 지침 (Riverpod 확정)

- **`flutter_riverpod` 채택 확정.**
- 실시간 화면은 **WS 이벤트 스트림 + STT 이벤트 스트림**을 구독하는 구조. `StreamProvider`로 raw 이벤트를 노출하고, `StateNotifier`(또는 `Notifier`)로 (위험도, 자막 리스트, 탐지 키워드, 경고 표시 여부)를 파생 상태로 관리.
- 설정값(임계값/테마/큰글씨)은 `shared_preferences`를 감싼 `Notifier`로 앱 전역 제공, 위험도 계산에 주입.
- 통화 종료 후 "요약/근거"는 세션 동안 앱이 **메모리에 누적한 발화·이벤트**로 만든다(과거 통화 상세 API가 없으므로 — `02_API_INTEGRATION.md`, `05_BACKEND_REQUESTS.md` 참고).
